This document describes how to integrate the HockeySDK-Mac into your app. The SDK has one main feature:

**Collect crash reports:** If your app crashes, a crash log with the same format as from the Apple Crash Reporter is written to the device's storage. If the user starts the app again, he is asked to submit the crash report to HockeyApp.

## IMPORTANT

This is a beta version of the upcoming HockeySDK-Mac. Do **NOT** use this in a production version of your apps!

Also please keep this beta private and don't share it with others. Thanks!

## Beta Notes

### What's New

Version 0.5.1:

- Added Mac Sandbox support:
  - Supports 32 and 64 bit Intel X86 architecture
  - Uses brand new PLCrashReporter version instead of crash logs from Libary directory
- Fixed sending crash reports to the HockeyApp servers

### Known issues:

- Small memory leak when detecting a crash report in PLCrashReporter (old bug, should be fixed soon)
- System calls in Last Exception Backtrace are not symbolicated

### What is pending:

- Open Source Release
- Catch exceptions from the runloop, right now you need to implement this [workaround](http://pastebin.com/hDXyhHhx) (Thanks to Max)
- Official support for multiple dSYMs per app version on the server (for framework symbols)

### What we need from you:

- Test it and report bugs :)
- Tell us what is missing?
- Tell us what kind of data you would need to be able to attach to crash reports.
- Contact us via our [Support Forum](http://support.hockeyapp.net/discussions) and please make the threads private. Thanks.

## Prerequisites

1. Before you integrate HockeySDK into your own app, you should add the app to HockeyApp if you haven't already. Read [this how-to](http://support.hockeyapp.net/kb/how-tos/how-to-create-a-new-app) on how to do it.

2. We also assume that you already have a project in Xcode and that this project is opened in Xcode 4.

## App Versioning

We suggest to handle beta and release versions in two separate *apps* on HockeyApp with their own bundle identifier (e.g. by adding "beta" to the bundle identifier), so

* both apps can run on the same device or computer at the same time without interfering,

* release versions do not appear on the beta download pages, and

* easier analysis of crash reports and user feedback.

We propose the following method to set version numbers in your beta versions:

* Use both "Bundle Version" and "Bundle Version String, short" in your Info.plist.

* "Bundle Version" should contain a sequential build number, e.g. 1, 2, 3.

* "Bundle Version String, short" should contain the target official version number, e.g. 1.0.

## Download & Extract

1. Download the latest version.

2. Unzip the file. A new folder HockeySDK-Mac is created.

3. Move the folder into your project directory. We usually put 3rd-party code into a subdirectory named "Vendor", so we move the directory into it.

## Integrate the SDK

1. Include `HockeySDK.framework` into your project

2. In your appDelegate change the invocation of the main window to the following structure and make sure not to invoke your main window automatically!<pre><code>// this delegate method is reequired 
`-` (void) showMainApplicationWindow {
		// launch the main app window
		// remember not to automatically show the main window if using NIBs
		[window makeFirstResponder: nil];
		[window makeKeyAndOrderFront:nil];
	}</code></pre>

3. In your appDelegate.m include<pre><code>#import <HockeySDK/CNSHockeyManager.h></code></pre>

4. Initialize the SDK e.g. in `applicationDidFinishLaunching`<pre><code>[[CNSHockeyManager sharedHockeyManager] configureWithIdentifier:@"APP_IDENTIFIER" companyName:@"My company" delegate:self];</code></pre>

5. Replace APP_IDENTIFIER with the app identifier of your beta app. If you don't know what the app identifier is or how to find it, please read [this how-to](http://support.hockeyapp.net/kb/how-tos/how-to-find-the-app-identifier). 

6. Implement delegate methods as mentioned below if you want to add custom data.

7. Done.

## Optional Delegate Methods

Besides the crash log, HockeyApp can show you fields with information about the user and an optional description. You can fill out these fields by implementing the following methods:

1. In your appDelegate.h include<pre><code>#import <HockeySDK/CNSCrashReportManagerDelegate.h></code></pre>

2. In your appDelegate.h add the CNSHockeyManagerDelegate protocol to your appDelegate:<pre><code>@interface DemoAppDelegate : NSObject <CNSHockeyManagerDelegate> {}</code></pre>

These are the available delegate methods:

* **crashReportUserID** should be a user ID or email, e.g. if your app requires to sign in into your server, you could specify the login here. The string should be no longer than 255 chars. 

* **crashReportContact** should be the user's name or similar. The string should be no longer than 255 chars.

* **crashReportLog** can be as long as you want it to be and contain additional information about the 
crash. For example, you can return a custom log or the last XML or JSON response from your server here.

If you implement these delegate methods and keep them in your live app too, please consider the privacy implications.

## Upload the .dSYM File

Once you have your app ready for beta testing or even to submit it to the App Store, you need to upload the .dSYM bundle to HockeyApp to enable symbolication. If you have built your app with Xcode4, menu Product > Archive, you can find the .dSYM as follows:

1. Chose Window > Organizer in Xcode.

2. Select the tab Archives.

3. Select your app in the left sidebar.

4. Right-click on the latest archive and select Show in Finder.

5. Right-click the .xcarchive in Finder and select Show Package Contents. 

6. You should see a folder named dSYMs which contains your dSYM bundle. If you use Safari, just drag this file from Finder and drop it on to the corresponding drop zone in HockeyApp. If you use another browser, copy the file to a different location, then right-click it and choose Compress "YourApp.dSYM". The file will be compressed as a .zip file. Drag & drop this file to HockeyApp. 

As an alternative for step 5 and 6, you can use our [HockeyMac](https://github.com/codenauts/HockeyMac) app to upload the complete archive in one step.

## Checklist if Crashes Do Not Appear in HockeyApp

1. Check if the BETA_IDENTIFIER or LIVE_IDENTIFIER matches the App ID in HockeyApp.

2. Check if CFBundleIdentifier in your Info.plist matches the Bundle Identifier of the app in HockeyApp. HockeyApp accepts crashes only if both the App ID and the Bundle Identifier equal their corresponding values in your plist and source code.

3. If it still does not work, please [contact us](http://support.hockeyapp.net/discussion/new).
