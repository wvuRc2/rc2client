//
//  Mac_Lib.h
//  Mac Lib
//
//  Created by Mark Lilback on 9/5/11.
//  Copyright (c) 2011 Agile Monks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Mac_Lib : NSObject

@end
